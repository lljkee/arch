// VK Flex Chrome Extension: injection.js

(function () {
'use strict';

class Injection {
    constructor () {
        // TODO: Check is demon ready
        this.extensionId = window.vkfExtensionId;

        this.modules = {};
        this.cache = {};
        this.observer = null;

        this.hooks = {
            addedNodes: [],
            removedNodes: [],
            onSidebarChanged: [],
            onLocationChanged: []
        };

        this.hideStyles = [
            'opacity: 0 !important;',
            'position: fixed !important;',
            'z-index: -5 !important;',
            'height: 0 !important;',
            'width: 0 !important;',
            'max-height: 0 !important;',
            'max-width: 0 !important;',
            'overflow: hidden !important;',
            'left: -99999px !important;',
            'top: -99999px !important;',
            'display: block !important;'
        ].join(' ');

        this.coreMessage('getInjectionData', (injectionData) => {
            this.settings = injectionData.settings;
            this.langData = injectionData.langData;

            this.loadModules();
            this.initObserver();

            if (injectionData.welcomeMessage) {
                this.showFastBox(injectionData.welcomeMessage, 1000, null, (isSuccess) => {
                    isSuccess && this.coreMessage('welcomeMessageIsShown');
                });
            }

            // TODO: Show omnibox tip
            /*
            that.showFastBox(that.lang_data['msg_obt']);
            that.coreMsg({
                action: 'omnibox_tip_is_shown'
            });
            */
        });

        this.log('And away we go...');
    }

    showFastBox (message, delay = 0, title = null, callback = () => {}) {
        setTimeout(() => {
            if (window.showFastBox) {
                window.showFastBox({
                    dark: 1,
                    title: title || this.lang('msg_title'),
                    bodyStyle: 'padding: 20px; line-height: 160%;'
                }, message);
                callback(true);
            } else {
                this.warn('[Injection.showFastBox] Can\'t show fastbox, global function showFastBox doesn\'t exist');
                callback(false);
            }
        }, delay);
    }

    getType (target) {
        return Object.prototype.toString.call(target).toLowerCase().match(/^\[\w+\s(\w+)\]$/)[1];
    }

    isObj (target) {
        return this.getType(target) === 'object';
    }

    isFunc (target) {
        return this.getType(target) === 'function';
    }

    isStr (target) {
        return this.getType(target) === 'string';        
    }

    log (...args) {
        console.log.call(console, '%c[VK Flex]', 'font-weight: bold;', ...args);
    }

    error (...args) {
        console.error.call(console, '%c[VK Flex]', 'font-weight: bold;', ...args);
    }

    warn (...args) {
        console.warn.call(console, '%c[VK Flex]', 'color: #bb7d0b; font-weight: bold;', ...args);
    }

    info (...args) {
        console.info.call(console, '%c[VK Flex]', 'color: blue; font-weight: bold;', ...args);
    }

    initObserver () {
        this.subscribe({
            name: 'injection',
            events: {
                addedNodes: { callback: this.onAddNode, context: this },
                removedNodes: { callback: this.onRemoveNode, context: this }
            } 
        });

        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                [ 'addedNodes', 'removedNodes' ].forEach((eventType) => {
                    mutation[eventType].forEach((node) => {
                        if (/^html.*element$/.test(this.getType(node)) && !node.vkfSkip) {
                            this.triggerEvent(eventType, node, mutation);
                        }
                    });
                });
            });
        });

        this.observer.observe(document.body, { 
            childList: true, 
            subtree: true
        });

        this.checkLocation();

        this.triggerEvent('addedNodes', document.body, {});
    }

    checkLocation () {
        if (window.location.href !== this.cache.lastLocationHref) {
            this.cache.lastLocationHref = window.location.href;
            this.triggerEvent('onLocationChanged', Object.assign({}, window.location));
        }

        requestAnimationFrame(() => this.checkLocation());
    }

    subscribe (options) {
        for (let eventType in options.events) {
            this.hooks[eventType].push({
                name: options.name,
                callback: options.events[eventType].callback,
                context: options.events[eventType].context
            });
        }        
    }

    onAddNode (node, mutation) {
        let sidebar = node.id == 'side_bar' ? node : node.querySelector('#side_bar');

        if (sidebar && sidebar !== this.cache.sidebar) {
            this.cache.sidebar = sidebar;
            this.triggerEvent('onSidebarChanged', sidebar);
        }
    }

    onRemoveNode (node, mutation) {

    }

    triggerEvent (eventType, ...handlerArgs) {
        this.hooks[eventType].forEach((hook) => {
            hook.callback.call(hook.context, ...handlerArgs);
        });
    }

    triggerDomEvent (target, eventType) {
        target.dispatchEvent(new Event(eventType));
    }

    loadModules () {
        // TODO: Calendar & URL Shortener disappear when user changes visibility of menu items

        // Left menu fix
        if (this.settings.fix_menu) {
            document.documentElement.classList.add('vkf-fixed-menu');
        }

        // Hide potential friends
        if (this.settings.hide_potential_friends) {
            document.documentElement.classList.add('vkf-hide-potential-friends');
        }

        // Hide big like in photo gallery
        if (this.settings.hide_photo_like) {
            document.documentElement.classList.add('vkf-hide-photo-like');            
        }

        // Calendar
        if (this.settings.add_calendar) {
            this.modules.calendar = new Calendar(this);
        }

        // Url shortener
        if (this.settings.url_shortener) {
            this.modules.urlShortener = new UrlShortener(this);
        }

        if (this.settings.simplify_audio_ui) {
            this.modules.audioUiSimplifier = new AudioUiSimplifier(this);
        }

        // Audio
        // if (this.settings.audio_downlink || this.settings.audio_info) {
        //     this.modules.audioProcessor = new AudioProcessor(this);
        // }

        // Video
        if (this.settings.video_downlink) {
            this.modules.videoProcessor = new VideoProcessor(this);
        }

        // Middlename field
        if (this.settings.add_middlename) {
            this.modules.middlenameField = new MiddlenameField(this);            
        }

        // Link "My video"
        if (this.settings.change_videos_link) {
            this.modules.myVideoLink = new MyVideoLink(this); 
        }

        // Ads Shredder
        if (this.settings.hide_advert) {
            this.modules.adsShredder = new AdsShredder(this);  
        }

        this.hpc = () => {
            this.modules.adsShredder && this.modules.adsShredder.hpc();
        };

        // Age and zodiac
        if (this.settings.show_user_age || this.settings.show_user_zodiac) {
            this.modules.userAgeAndZodiac = new UserAgeAndZodiac(this); 
        }

        // Away.php
        if (this.settings.skip_redirect) {
            this.modules.awaySkip = new AwaySkip(this); 
        }

        // Force redraw
        requestAnimationFrame(() => this.triggerDomEvent(window, 'scroll'));
    }

    coreMessage (...args) { // action, data, callback
        window.chrome.runtime.sendMessage(
            this.extensionId, 
            Object.assign({ _action: args[0] }, this.isObj(args[1]) ? args[1] : {}), 
            this.isFunc(args[1]) ? args[1] : (this.isFunc(args[2]) ? args[2] : () => {})
        );
    }

    lang (key) {
        return (key in this.langData) ? this.langData[key] : key;
    }

    clearFileTitle (title) {
        let htmlFilter = document.createElement('div');
        htmlFilter.innerHTML = title;
        return htmlFilter.innerText.replace(/[\\\/:\*\?"<>\|]/g, '').trim().replace(/\s+/g, ' ');
    }

    formatSize (bytes) {
        let size = '';

        if (bytes < 1000) {
            size = bytes + ' ' + this.lang('units_b');
        } else if (bytes < 943718) {
            size = (Math.round(bytes / 1024 * 10) / 10).toFixed(1) + ' ' + this.lang('units_kb');
        } else if (bytes < 966367642) {
            size = (Math.round(bytes / 1048576 * 10) / 10).toFixed(1) + ' ' + this.lang('units_mb');
        } else {
            size = (Math.round(bytes / 1073741824 * 10) / 10).toFixed(2) + ' ' + this.lang('units_gb');
        }

        return size;
    }

    bindEventHandler (target, eventFullName, handler, context) {
        let handlerWrap = (event) => {
            if (handler.call(context, event, target) === false) {
                event.preventDefault();
                event.stopPropagation();
            }                
        };

        let [ eventName, eventNamespace ] = eventFullName.split('.');

        // Link handler with node for future unbind
        if (eventNamespace) {
            !target.vkfEventsMap && (target.vkfEventsMap = {});
            target.vkfEventsMap[eventFullName] = handlerWrap;
        }

        return target.addEventListener(eventName, handlerWrap, false);
    }

    unbindEventHandler (target, eventFullName) {
        let [ eventName, eventNamespace ] = eventFullName.split('.');

        if (!eventNamespace) {
            this.warn('unbindEventHandler: only events with namespace can be unbinded');
            return;
        }

        let handler = (target.vkfEventsMap || {})[eventFullName];
        handler && target.removeEventListener(eventName, handler, false);
    }

    downloadFile (e, target) {
        e.stopPropagation();

        switch (e.type) {
            case 'click':
                e.preventDefault();

                if (target.href) {
                    this.coreMessage('downloadFile', {
                        href: target.href,
                        download: target.download || ''
                    });
                }

                break;

            case 'dragstart':
                if (target.tagName.toLowerCase() != 'a') {
                    target = target.querySelector('a');
                }

                if (target && target.href) {
                    let mimeType = target.dataset.type,
                        filename = target.download || target.href.split('/').pop();

                    if (mimeType) {
                        e.dataTransfer.setData('DownloadURL', `${mimeType}:${filename}:${target.href}`);
                    }
                }

                break;
        }
    }

    inArray (item, array) {
        return array.indexOf(item) !== -1;
    }

    createNode (model, parent) {
        let node;

        if (model.tag) {
            node = document.createElement(model.tag);
            delete model.tag;

            for (let key in model) {
                let val = model[key];

                if (this.inArray(key, ['href', 'id', 'innerHTML', 'innerText'])) {
                    node[key] = val;
                } else if (key == 'class') {
                    node.className = Array.isArray(val) ? val.join(' ') : val;
                } else if (key == 'child') {
                    val = Array.isArray(val) ? val : [val];
                    val.forEach((childModel) => this.createNode(childModel, node));
                } else if (key == 'data') {
                    for (let dataKey in val) {
                        node.dataset[dataKey] = val[dataKey];
                    }
                } else if (key == 'events') {
                    val.forEach((eventOptions) => this.bindEventHandler(node, ...eventOptions));
                } else {
                    node.setAttribute(key, val); 
                }
            }

            // Add this flag to all nodes created by VK Flex
            // Mutation observers will skip these nodes
            node.vkfSkip = true;
        } else if ('text' in model) {
            node = document.createTextNode(model.text);
        }

        parent && parent.appendChild(node);

        return node;
    };

    prependNode (parentNode, childNode) {
        parentNode = this.isObj(parentNode) ? this.createNode(parentNode) : parentNode;
        childNode = this.isObj(childNode) ? this.createNode(childNode) : childNode;
        parentNode.insertBefore(childNode, parentNode.firstChild);
    }

    inputSelectAll (input) {
        input.setSelectionRange(0, input.value.length);
    }

    makeNodeInvisible (node) {
        node.removeAttribute('style');
        node.dataset.invisibleNode = 'true';
    }
}

class AwaySkip {
    constructor (app) {
        this.app = app;
    
        this.app.subscribe({
            name: 'awaySkip',
            events: {
                addedNodes: { callback: this.onAddNode, context: this }
            } 
        });
    }

    clearLink (anchor) {
        let href = anchor.href.match(/(?:\?|&)to=([^\?&]*)/);

        if (href) {
            try {
                href = decodeURIComponent(href[1]);
            } catch (e) {
                this.app.warn('[AwaySkip.clearLink]', 'Cant\'t decodeURIComponent href:', href);
                return;
            }

            if (href.indexOf('://') != -1) {
                anchor.href = href;
            }            
        }
    }

    onAddNode (node) {
        if (node.href && node.href.startsWith('/away.php')) {
            this.clearLink(hode);
        }

        node.querySelectorAll("a[href^='/away.php']").forEach((anchor) => {
            this.clearLink(anchor);
        });      
    }
}

class AudioUiSimplifier {
    constructor (app) {
        this.app = app;

        this.app.subscribe({
            name: 'audioUiSimplifier',
            events: {
                onLocationChanged: { callback: this.onLocationChanged, context: this }
            } 
        });
    }

    onLocationChanged (location) {
        if (!(/^\/(audio|audios\-?\d+)$/.test(location.pathname) || window.cur && window.cur.module == 'audio')) {
            return;
        }

        const layout = document.querySelector('.audio_page_layout');

        if (!layout) {
            return;
        }

        layout.classList.add('vkf-simplified-ui');

        const playlists = layout.querySelector('.audio_page_layout.vkf-simplified-ui > .audio_page_content_block_wrap > ._audio_page_content_block > .audio_page_sections > .audio_section__all ._audio_page__playlists');

        if (playlists && playlists.parentNode.classList.contains('_audio_page_titled_block')) {
            const sep = playlists.parentNode.nextElementSibling;

            sep && sep.classList.contains('audio_page_separator') && sep.remove();
            playlists.parentNode.remove();
        }
    }
}

class UserAgeAndZodiac {
    constructor (app) {
        this.app = app;

        this.screenName = null;

        this.app.subscribe({
            name: 'userAgeAndZodiac',
            events: {
                onLocationChanged: { callback: this.onLocationChanged, context: this }
            } 
        });
    }

    onLocationChanged (location) {
        let urlParts = location.pathname.match(/[^\/]+/g);

        if (urlParts && urlParts.length == 1) {
            let screenName = this.screenName = urlParts[0],
                profileRowsWrap = document.body.querySelector('#profile #profile_short');

            if (profileRowsWrap && !profileRowsWrap.vkfAgeAndZodiac) {
                profileRowsWrap.vkfAgeAndZodiac = true;

                this.app.coreMessage(
                    'getUserAge', 
                    { 
                        screenName: screenName
                    }, 
                    (birthday) => {
                        if (birthday && this.screenName == screenName) {
                            let [ day, month, year ] = birthday.split('.').map((num) => Number(num));

                            // Zodiac
                            if (this.app.settings.show_user_zodiac && day && month && !profileRowsWrap.querySelector('[data-zodiac]')) {
                                this.showZodiac(profileRowsWrap, day, month);
                            }

                            // Age
                            if (this.app.settings.show_user_age && day && month && year && !profileRowsWrap.querySelector('[data-age]')) {
                                this.showAge(profileRowsWrap, day, month, year);
                            }
                        }
                    }
                );
            }
        } else {
            this.screenName = null;
        }
    }

    showZodiac (profileRowsWrap, day, month) {
        let zodiac = null;

             if (month == 12 && day > 21 || month == 1  && day < 20) { zodiac = 1;  }
        else if (month == 1  && day > 19 || month == 2  && day < 19) { zodiac = 2;  }   
        else if (month == 2  && day > 18 || month == 3  && day < 21) { zodiac = 3;  }
        else if (month == 3  && day > 20 || month == 4  && day < 20) { zodiac = 4;  }
        else if (month == 4  && day > 19 || month == 5  && day < 21) { zodiac = 5;  }
        else if (month == 5  && day > 20 || month == 6  && day < 22) { zodiac = 6;  }
        else if (month == 6  && day > 21 || month == 7  && day < 23) { zodiac = 7;  }
        else if (month == 7  && day > 22 || month == 8  && day < 23) { zodiac = 8;  }
        else if (month == 8  && day > 22 || month == 9  && day < 23) { zodiac = 9;  }
        else if (month == 9  && day > 22 || month == 10 && day < 23) { zodiac = 10; }
        else if (month == 10 && day > 22 || month == 11 && day < 22) { zodiac = 11; }
        else if (month == 11 && day > 21 || month == 12 && day < 22) { zodiac = 12; }

        if (zodiac) {
            this.app.prependNode(
                profileRowsWrap,
                {
                    tag: 'div',
                    class: [ 'clear_fix', 'profile_info_row' ],
                    data: { zodiac: 'true' },
                    child: [
                        {
                            tag: 'div',
                            class: 'label fl_l',
                            innerHTML: this.app.lang('profile_label_zodiac') + ':'
                        },
                        {
                            tag: 'div',
                            class: 'labeled',
                            innerHTML: this.app.lang('zodiac_' + zodiac)                                               
                        }
                    ]
                }
            );                                    
        }
    }

    showAge (profileRowsWrap, day, month, year) {
        let ageCases = this.app.lang('profile_age').split('|'),
            currentDate = new Date(),
            age = (currentDate.getFullYear() - year - ((currentDate.getMonth() - --month || currentDate.getDate() - day) < 0)),
            ageCase = (age % 10 == 0 || age % 10 >= 5 && age % 10 <= 9 || age % 100 >= 5 && age % 100 <= 20) ? 0 : (age % 10 == 1 ? 1 : 2);

        this.app.prependNode(
            profileRowsWrap,
            {
                tag: 'div',
                data: { age: 'true' },
                class: [ 'clear_fix', 'profile_info_row' ],
                child: [
                    {
                        tag: 'div',
                        class: 'label fl_l',
                        innerHTML: this.app.lang('profile_label_age') + ':'
                    },
                    {
                        tag: 'div',
                        class: 'labeled',
                        child: {
                            tag: 'a',
                            href: `/search?c[section]=people&c[age_from]=${age}`,
                            innerHTML: age + ' ' + ageCases[ageCase]
                        }
                                                                     
                    }
                ]
            }
        ); 
    }
}

class AdsShredder {
    static get SELECTORS () {
        return [
            [ '.apps_feedRightAppsBlock', null ],
            [ `[class*='_recommend_apps']`, null ],
            [ '.feed_friends_recomm', null ],
            [ '.profile_friends_recomm', null ],
            [ '.audio_promo', null ],
            [ '.page_block.post_marked_as_ads', null ],
            [ '.page_block .wall_marked_as_ads', '.page_block' ],
            [ '._ads_block_data_w, .ads_ads_news_wrap', '.feed_row, .feed_row_unshown' ],
            [ '.page_block #group_recom_wrap', '.page_block' ],
            [ '#stories_feed_wrap', null ],
            [ '#side_bar #ads_left', null ],
            [ '#ads_special_promo_wrap', null ]
        ];
    }

    constructor (app) {
        this.app = app;

        this.app.subscribe({
            name: 'adsShredder',
            events: {
                onSidebarChanged: { callback: this.onSidebarChanged, context: this },
                addedNodes: { callback: this.onAddNode, context: this }
            } 
        });

        this.disableAudioAds();
        this.hpc_check();
    }

    hpc () {        
        window.localStorage.setItem('vkf_hpc', '1');
        this.hpc_check();
    }

    hpc_check () {
        if (window.localStorage.getItem('vkf_hpc')) {
            document.documentElement.classList.add('vkf-hide-post-comments');
        }
    }

    disableAudioAds () {
        if (!window.AudioPlayer) {
            return setTimeout(() => this.disableAudioAds(), 3000);
        }

        const AP = window.AudioPlayer;

        AP.prototype._adsIsAllowed = (window.ap || {})._adsIsAllowed = function () { 
            return {
                type: 'ADS_ALLOW_DISABLED' in AP ? AP.ADS_ALLOW_DISABLED : 1
            }; 
        };
    }

    // Ads in sidebar
    onSidebarChanged (sidebar) {
        if (sidebar) {
            const ads = sidebar.querySelector('#ads_left');
            ads && ads.remove();
        }
    }

    // Ads in feed
    onAddNode (node) {
        AdsShredder.SELECTORS.forEach(([ sel, ancSel ]) => {
            const nodes = node.matches(sel) ? [ node ] : Array.from(document.querySelectorAll(sel));

            nodes.forEach((el) => (ancSel && el.closest(ancSel) || el).remove());
        });
    }
}

class MyVideoLink {
    constructor (app) {
        this.app = app;

        this.observer = null;

        this.app.subscribe({
            name: 'myVideoLink',
            events: {
                onSidebarChanged: { callback: this.onSidebarChanged, context: this }
            } 
        });
    }

    onSidebarChanged (sidebar) {
        if (sidebar) {
            let anchor = sidebar.querySelector('#l_vid > a');

            if (anchor) {
                anchor.href = '/videos';
            }

            this.setObserver(sidebar);
        }
    }

    setObserver (sidebar) {
        this.observer && this.observer.disconnect();

        this.observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.target.parentNode.id == 'l_vid') {
                    if (mutation.target.href.indexOf('/videos') == -1) {
                        mutation.target.href = '/videos';
                    }
                }
            });
        });

        this.observer.observe(sidebar, { 
            attributes: true, 
            subtree: true,
            attributeFilter: [ 'href' ]
        });
    }
}

class MiddlenameField {
    constructor (app) {
        this.app = app;
    
        this.app.subscribe({
            name: 'middlenameField',
            events: {
                addedNodes: { callback: this.onAddNode, context: this }
            } 
        });
    }

    onAddNode (node) {
        let lastNameRow = node.querySelector('input#pedit_last_name');

        if (lastNameRow) {
            lastNameRow = lastNameRow.closest('.pedit_row');

            if (!lastNameRow.parentNode.querySelector('input#pedit_middle_name')) {
                lastNameRow.parentNode.insertBefore(
                    this.app.createNode({
                        tag: 'div',
                        class: [ 'pedit_row', 'clear_fix' ],
                        child: [
                            {
                                tag: 'div',
                                class: 'pedit_label',
                                innerText: this.app.lang('middlename_label') + ':'
                            },
                            {
                                tag: 'div',
                                class: 'pedit_labeled',
                                child: {
                                    tag: 'input',
                                    class: 'dark',
                                    id: 'pedit_middle_name',
                                    type: 'text',
                                    autocomplete: 'off'
                                }
                            }
                        ]
                    }),
                    lastNameRow.nextSibling
                );
            }
        }        
    }
}

class VideoProcessor {
    static get QUALITIES () {
        return [ 240, 360, 480, 720, 1080 ];
    }

    constructor (app) {
        this.app = app;

        this.videoId = null;
        this.videoWrap = null;
        this.prevVideoId = null;
        this.linksNode = null;
        this.layerNode = null;

        this.app.subscribe({
            name: 'videoProcessor',
            events: {
                onLocationChanged: { 
                    callback: this.onLocationChanged, 
                    context: this 
                }
            } 
        });
    }

    extractVideoExtension (url, defaultValue = '.mp4') {
        return (url.match(/^.*(\.\w+)(?:\?.*)?$/) || [ null, defaultValue ])[1];
    }

    extractVideoQuality (url, defaultValue = 720) {
        return Number((url.match(/^.*\.(\d+)\.\w+(?:\?.*)?$/) || [ null, defaultValue ])[1]);
    }

    onLocationChanged (location) {
        let videoIdMatch = location.href.match(/(?:\/|=)video(\-?\d+_\d+)/);

        this.videoWrap = null;

        if (this.linksNode) {
            this.linksNode.remove();
            this.linksNode = null;
        }

        if (this.layerNode) {
            this.app.unbindEventHandler(this.layerNode, 'scroll.layerScroll');
            this.layerNode = null;
        }

        if (videoIdMatch) {
            this.prevVideoId = this.videoId || null;
            this.videoId = videoIdMatch[1];
            setTimeout(() => this.findVideoBoxWrap(), 0); // fork
        } else {
            this.prevVideoId = null;
            this.videoId = null;
        }
    }

    findVideoBoxWrap () {
        if (!this.videoId) {
            return;
        }

        let videoWrap = document.querySelector('.video_box_wrap'),
            videoWrapId = videoWrap && videoWrap.id || '';

        if (videoWrap && (!this.prevVideoId || this.prevVideoId && videoWrapId.indexOf(this.prevVideoId) === -1)) {
            if (videoWrapId.indexOf(this.videoId) !== -1) {
                this.videoWrap = videoWrap;
                this.findVideoVars();
            }
        } else {
            if (!document.querySelector('.mv_video_unavailable_message_wrap')) { // !claimed
                setTimeout(() => this.findVideoBoxWrap(), 50);
            }
        }
    }

    findVideoVars () {
        if (!this.videoId) {
            return;
        }

        let videoVars = null;

        try { videoVars = mvcur.player.getVars(); } catch (e) {}

        if (videoVars && this.videoId == ((videoVars.oid || '') + '_' + (videoVars.vid || ''))) {
            this.processVideoVars(videoVars);
        } else {
            setTimeout(() => this.findVideoVars(), 50);
        }
    }

    processVideoVars (videoVars) {
        if (!this.videoId) {
            return;
        }

        let qualities = [];

        let title = 
            this.app.clearFileTitle(
                videoVars.md_title ||
                this.videoWrap.closest('#mv_box').querySelector('#mv_title').innerText ||
                'Untitled'
            );

        VideoProcessor.QUALITIES.forEach((quality) => {
            let url = videoVars['url' + quality] || videoVars['cache' + quality];

            if (url) {
                qualities.push({
                    quality: quality,
                    filename: title + this.extractVideoExtension(url),
                    url: url,
                    size: null
                });
            }
        });

        if (!qualities.length && videoVars.postlive_mp4) {
            let url = videoVars.postlive_mp4;

            qualities.push({
                quality: this.extractVideoQuality(url),
                filename: title + this.extractVideoExtension(url),
                url: url,
                size: null
            });
        }

        if (qualities.length) {
            let playerNode = this.videoWrap.closest('#mv_main');

            if (this.app.settings.video_show_size) {
                let requestCount = qualities.length;

                qualities.forEach((quality) => {
                    this.app.coreMessage(
                        'getFileSize', 
                        { 
                            url: quality.url 
                        }, 
                        (size) => {
                            quality.size = size;
                            if (!--requestCount) {
                                this.showVideoLinks(playerNode, qualities);
                            }
                        }
                    );
                });
            } else {
                this.showVideoLinks(playerNode, qualities);
            }
        }
    }

    showVideoLinks (playerNode, qualities) {
        if (!this.videoId) {
            return;
        }

        let linksModel = {
            tag: 'div',
            id: 'video-download-wrap',
            child: []
        };

        qualities.forEach((quality) => {
            let linkModel = {
                tag: 'div',
                draggable: 'true',
                events: [ [ 'dragstart', this.app.downloadFile, this.app ] ],
                child: {
                    tag: 'a',
                    draggable: 'false',
                    href: quality.url,
                    download: quality.filename,
                    data: { type: 'video/mpeg' },
                    events: [ [ 'click', this.app.downloadFile, this.app ] ],
                    child: [
                        {
                            text: quality.quality + 'p'
                        }
                    ]
                }
            };

            if (this.app.settings.video_show_size && quality.size !== null) {
                linkModel.child.child.push({
                    tag: 'span',
                    innerHTML: this.app.formatSize(quality.size)
                });
            }
                
            linksModel.child.push(linkModel);
        });

        this.linksNode = this.app.createNode(linksModel);

        playerNode.appendChild(this.linksNode);

        requestAnimationFrame(() => {
            this.linksNode.classList.add('animate');

            let linksNodeRect = this.linksNode.getBoundingClientRect();
            this.linksNode.style.width = linksNodeRect.width + 'px';
            this.linksNode.style.height = linksNodeRect.height + 'px';
        });

        // -------------------

        this.layerNode = playerNode.closest('#mv_layer_wrap');

        this.app.bindEventHandler(this.layerNode, 'scroll.layerScroll', (e) => {
            let playerNodeRect = playerNode.getBoundingClientRect();

            if (playerNodeRect.top <= 0) {
                if (!this.linksNode.classList.contains('sticky')) {
                    let linksNodeRect = this.linksNode.getBoundingClientRect();
                    this.linksNode.style.width = linksNodeRect.width + 'px';
                    this.linksNode.style.top = linksNodeRect.top + 'px';
                    this.linksNode.style.left = playerNodeRect.right + 'px';
                    this.linksNode.classList.add('sticky');
                }
            } else {
                if (this.linksNode.classList.contains('sticky')) {
                    this.linksNode.classList.remove('sticky');
                    this.linksNode.style.top = '';
                    this.linksNode.style.left = '';
                }
            }
        }, this);
    }
}

class Calendar {
    constructor (app) {
        this.app = app;

        this.app.subscribe({
            name: 'calendar',
            events: {
                onSidebarChanged: { callback: this.onSidebarChanged, context: this }
            } 
        });
    }

    onSidebarChanged (sidebar) {
        if (sidebar && !sidebar.querySelector('#vkf-calendar-item')) {
            let listNode = sidebar.querySelector('ol');

            listNode.insertBefore(
                this.app.createNode({
                    tag: 'li',
                    id: 'vkf-calendar-item',
                    child: {
                        tag: 'a',
                        href: '#',
                        class: 'left_row',
                        events: [ [ 'click', this.onClick, this ] ],
                        child: {
                            tag: 'span',
                            class: 'left_fixer',
                            child: [
                                {
                                    tag: 'span',
                                    class: [ 'left_icon', 'fl_l' ]
                                },
                                {
                                    tag: 'span',
                                    class: [ 'left_label', 'inl_bl' ],
                                    innerHTML: this.app.lang('calendar')
                                }
                            ]
                        }
                    }
                }),
                listNode.querySelector('.more_div.l_main')
            );
        }
    }

    onClick (event, target) {
        let url = window.location.href,
            wPattern = /(?!\?|&)w=[^\?&]+/;

        if (wPattern.test(url)) {
            url = url.replace(wPattern, 'w=calendar');
        } else {
            url += (/\?/.test(url) ? '&' : '?') + 'w=calendar';
        }

        target.href = url;

        return window.nav.go(target, event, { noback: true }); 
    }
}

class UrlShortener {
    constructor (app) {
        this.app = app;

        this.app.subscribe({
            name: 'urlShortener',
            events: {
                onSidebarChanged: { callback: this.onSidebarChanged, context: this }
            } 
        });
    }

    onSidebarChanged (sidebar) {
        if (sidebar && !sidebar.querySelector('#vkf-url-shortener-item')) {
            let listNode = sidebar.querySelector('ol');

            listNode.insertBefore(
                this.app.createNode({
                    tag: 'li',
                    id: 'vkf-url-shortener-item',
                    class: 'vkf-sb-us-li',
                    child: {
                        tag: 'span',
                        class: 'left_row',
                        child: {
                            tag: 'span',
                            class: 'left_fixer',
                            child: [
                                {
                                    tag: 'span',
                                    class: [ 'left_icon', 'fl_l' ]
                                },
                                {
                                    tag: 'span',
                                    class: 'vkf-us-form',
                                    child: {
                                        tag: 'form',
                                        action: '/cc',
                                        method: 'POST',
                                        events: [ [ 'submit', this.onSubmit, this ] ],
                                        child: {
                                            tag: 'input',
                                            type: 'text',
                                            id: 'vkf-url-shortener-input',
                                            value: this.app.lang('url_shorten'),
                                            placeholder: this.app.lang('enter_for_submit'),
                                            events: [ 
                                                [ 'focusin', this.onFocusChange, this ],
                                                [ 'focusout', this.onFocusChange, this ]
                                            ]
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }),
                listNode.querySelector('.more_div.l_main')
            );
        }
    }

    onSubmit (event, target) {
        let listItem = target.closest('.vkf-sb-us-li');

        target = target.querySelector("input[type='text']");

        let setProgress = (isProgress) => {
            listItem.classList[isProgress ? 'add' : 'remove']('vkf-sb-us-li-progress');
        };

        let url = target.value.trim();

        if (url) {
            setProgress(true);

            this.app.coreMessage(
                'getShortUrl', 
                { url }, 
                (response) => {
                    setProgress(false);

                    if (response.error) {
                        this.app.showFastBox(response.error);
                    } else {
                        target.value = response.url;

                        setTimeout(() => target === document.activeElement && this.app.inputSelectAll(target), 0);
                    }
                }
            );
        }

        /*
        window.ajax.post(
            '/cc', 
            {
                act: 'shorten', 
                link: target.value
            }, 
            {
                onDone: (text) => {
                    if (listItem.classList.contains('vkf-sb-us-li-progress')) {
                        setProgress(false);
                    }

                    if (text) {
                        target.value = text;

                        setTimeout(() => {
                            if (target === document.activeElement) {
                                this.app.inputSelectAll(target);
                            } else {
                                target.focus();
                            }
                        }, 0);
                    }
                },
                onFail: (text) => {
                    setProgress(false);

                    if (this.app.isStr(text)) {
                        alert(text);
                    }

                    // Prevent system error message
                    return true;
                },
                showProgress: () => {
                    setProgress(true);
                }
            }
        );
        */

        return false;
    }

    onFocusChange (event, target) {
        let listItem = target.closest('.vkf-sb-us-li');

        if (listItem) {
            if (event.type == 'focusin') {
                listItem.classList.add('vkf-sb-us-li-focus');

                if (target.value == this.app.lang('url_shorten')) {
                    target.value = '';
                } else {
                    this.app.inputSelectAll(target);
                }
            } else {
                listItem.classList.remove('vkf-sb-us-li-progress', 'vkf-sb-us-li-focus');
                target.value = this.app.lang('url_shorten');
            }
        }
    }
}

class AudioProcessor {
    static get MAX_AUDIOS_PER_REQUEST () { 
        return 10; 
    }

    static get REQUESTS_INTERVAL () { 
        return 350; // ms
    }

    static get MAX_RETRIES_PER_AUDIO () { 
        return 3; 
    }

    static get FIND_ROWS_INTERVAL () { 
        return 150; 
    }

    static get LONG_PAUSE () { 
        return 40 * 1000; // 40 sec 
    }

    constructor (app) {
        this.app = app;

        this.pendingAudio = {};
        this.tasksQueue = [];
        this.requestTimer = null;
        this.needFindAudioRows = true;
        this.longPause = 0;

        this.app.subscribe({
            name: 'audioProcessor',
            events: {
                addedNodes: { 
                    callback: function () { // do not use arrow function here
                        this.needFindAudioRows = true; 
                    }, 
                    context: this 
                }
            } 
        });

        this.findAudioRows();
    }

    updateAudioData (audioData, key, value) {
        audioData.secondary.saveToCache = audioData.secondary.saveToCache || audioData.primary[key] !== value;
        audioData.primary[key] = value;
        return audioData;
    }

    buildFilename (artist = '', title = '') {
        return this.app.clearFileTitle((artist || 'Unknown') + ' - ' + (title || 'Untitled')) + '.mp3';
    }

    calcQuality (size, duration) {
        return Math.min(320, Math.round(size / duration / 125 / 32) * 32);
    }

    findAudioRows () {
        if (this.needFindAudioRows) {
            this.needFindAudioRows = false;

            document.body
                .querySelectorAll('.audio_row:not([data-vkf-processed])')
                .forEach((audioRow) => {
                    let audioId = audioRow.dataset.fullId;

                    audioRow.dataset.vkfProcessed = 'true';

                    // ���� � ������� ������� ��� ���� ���� � ���� id
                    if (this.isPendingAudioExists(audioId)) {
                        this.addPendingAudio(audioId, audioRow);

                    // ���� ����� ��� ���� ��������� � ����� ������, �� �� ��������� ������ ��� ����
                    } else if (audioRow.classList.contains('claimed') || audioRow.closest('#narrow_column')) {
                        return;

                    // ��� ����, ������� ����� ����������
                    } else {
                        this.app.coreMessage('getAudioCache', {
                            audioId: audioId
                        }, (audioData) => {
                            audioData = {
                                primary: audioData,
                                secondary: {}
                            };

                            let nativeAudioData = [],
                                isUrlReliable = false;

                            try {
                                nativeAudioData = JSON.parse(audioRow.dataset.audio);
                            } catch (e) {}

                            // ----------------

                            // Title
                            if (nativeAudioData[4] && nativeAudioData[3]) {
                                audioData.secondary.filename = this.buildFilename(nativeAudioData[4], nativeAudioData[3]);
                            } else {
                                audioData.secondary.filename = null;
                            }

                            // Url
                            if (nativeAudioData[2]) {
                                this.updateAudioData(audioData, 'url', nativeAudioData[2]);
                                isUrlReliable = true;
                            }

                            // Duration
                            if (nativeAudioData[5]) {
                                this.updateAudioData(audioData, 'duration', nativeAudioData[5]);
                            }

                            // Quality
                            if (audioData.primary.size !== null && audioData.primary.duration !== null && audioData.primary.quality === null) {
                                this.updateAudioData(audioData, 'quality', this.calcQuality(audioData.primary.size, audioData.primary.duration));
                            }

                            // ----------------

                            audioData.secondary.needSize = 
                                (this.app.settings.audio_info == 1 || this.app.settings.audio_info == 2) && audioData.primary.quality === null && audioData.primary.size === null || 
                                (this.app.settings.audio_info == 1 || this.app.settings.audio_info == 3) && audioData.primary.size === null;

                            audioData.secondary.needDuration = 
                                (this.app.settings.audio_info == 1 || this.app.settings.audio_info == 2) && audioData.primary.quality === null && audioData.primary.duration === null;

                            // ----------------

                            // ���� ������ ������ �����
                            if (this.app.settings.audio_downlink || audioData.secondary.needSize) {
                                // ���������� ������
                                if (audioData.secondary.needDuration) {
                                    // (����� ������) � (����� ������������)
                                    this.addPendingAudio(audioId, audioRow, audioData);
                                    this.addTask(audioId);
                                } else {
                                    if (isUrlReliable) {
                                        // (���� ������ ������) � (� ������������� �� ����)
                                        if (audioData.secondary.needSize) {
                                            this.getSize(audioData.primary.url, (size) => {
                                                if (size !== null) {
                                                    this.updateAudioData(audioData, 'size', size);
                                                    audioData.secondary.needSize = false;
                                                }
                                                this.showAudioInfo(audioId, audioRow, audioData);
                                            });
                                        } else {
                                            this.showAudioInfo(audioId, audioRow, audioData);
                                        }
                                    } else if (audioData.primary.url) {
                                        // (����� ������) � (���� ������ ������) 
                                        this.getSize(audioData.primary.url, (size) => {
                                            if (size === null) {
                                                // (����� ������)
                                                this.addPendingAudio(audioId, audioRow, audioData);
                                                this.addTask(audioId);
                                            } else {
                                                this.updateAudioData(audioData, 'size', size);
                                                this.showAudioInfo(audioId, audioRow, audioData);
                                            }
                                        });
                                    } else {
                                        // (����� ������) � (��� ������)
                                        this.addPendingAudio(audioId, audioRow, audioData);
                                        this.addTask(audioId);
                                    }
                                }
                            } else {
                                this.showAudioInfo(audioId, audioRow, audioData);
                            }
                        });
                    }
                });
        }

        setTimeout(() => this.findAudioRows(), AudioProcessor.FIND_ROWS_INTERVAL);
    }

    isPendingAudioExists (audioId) {
        return audioId in this.pendingAudio;
    }

    addPendingAudio (audioId, audioRow, audioData = null) {
        if (!this.pendingAudio[audioId]) {
            this.pendingAudio[audioId] = { 
                audioNodes: [], 
                audioData: null
            };
        }

        if (audioData) {
            this.pendingAudio[audioId].audioData = audioData;
        }

        return this.pendingAudio[audioId].audioNodes.push(audioRow);
    }

    getPendingAudioData (audioId) {
        return this.pendingAudio[audioId] ? this.pendingAudio[audioId].audioData : {};        
    }

    pullPendingAudio (audioId) {
        let audioRows = [];

        if (this.pendingAudio[audioId]) {
            audioRows = this.pendingAudio[audioId].audioNodes;
            delete this.pendingAudio[audioId];
        }

        return audioRows;
    }

    addTask (id, attempts = 0, toTopOfQueue = false) {
        this.tasksQueue[toTopOfQueue ? 'unshift' : 'push']({
            id: id,
            attempts: attempts
        });

        if (this.requestTimer === null) {
            this.setRequestTimer();
        }
    }

    setRequestTimer () {
        clearTimeout(this.requestTimer);

        if (this.tasksQueue.length) {
            this.requestTimer = setTimeout(() => this.requestAudiosData(), this.longPause + AudioProcessor.REQUESTS_INTERVAL);
            this.longPause = 0;
        } else if (this.requestTimer !== null) {
            this.requestTimer = null;
        }
    }

    requestAudiosData () {
        if (!window.ajax) {
            this.setRequestTimer();
            this.app.warn('requestAudiosData: vk ajax object is not defiend');
            return;
        }

        let tasks = this.tasksQueue.splice(0, AudioProcessor.MAX_AUDIOS_PER_REQUEST);

        window.ajax.post(
            'al_audio.php', 
            {
                act: 'reload_audio', 
                al:  1,
                ids: tasks.map((task) => task.id).join(',')
            }, 
            {
                onDone: (receivedAudioData) => {
                    this.processAudioData(tasks, receivedAudioData || []);
                },
                onFail: () => this.processAudioData(tasks, [])
            }
        ); 
    }

    getSize (url, callback) {
        this.app.coreMessage('getFileSize', { url: url }, callback);
    }

    processAudioData (completedTasks, receivedAudioData) {
        // Add long pause if it was bulk request and empty response has been received
        if ((!receivedAudioData || !receivedAudioData.length) && completedTasks.length > 1) {
            this.longPause = AudioProcessor.LONG_PAUSE;
            this.app.info(`processAudioData: Long pause ${this.longPause} ms...`);
        }

        receivedAudioData = receivedAudioData.reduce((accumulator, audioData) => {
            accumulator[audioData[1] + '_' + audioData[0]] = {
                url: audioData[2],
                filename: this.buildFilename(audioData[4], audioData[3]),
                duration: audioData[5],
                datasetAudio: JSON.stringify(audioData)
            }; 
            return accumulator; 
        }, {});
        
        completedTasks.forEach((task) => {
            let audioId = task.id,
                audioCache = this.getPendingAudioData(audioId);

            task.attempts++;

            // Success
            if (audioId in receivedAudioData) {
                let audioData = receivedAudioData[audioId];

                audioCache.secondary.filename = audioData.filename;
                audioCache.secondary.datasetAudio = audioData.datasetAudio;

                this.updateAudioData(audioCache, 'url', audioData.url);
                this.updateAudioData(audioCache, 'duration', audioData.duration);

                if (audioCache.secondary.needSize) {
                    this.getSize(audioCache.primary.url, (size) => {
                        if (size !== null) {
                            this.updateAudioData(audioCache, 'size', size);
                            audioCache.secondary.needSize = false;
                        }

                        this.showAudioInfo(audioId, this.pullPendingAudio(audioId), audioCache);
                    });

                } else {
                    this.showAudioInfo(audioId, this.pullPendingAudio(audioId), audioCache);
                }

            // Next attempt
            } else if (task.attempts < AudioProcessor.MAX_RETRIES_PER_AUDIO) {
                this.addTask(audioId, task.attempts, true);

            // Error
            } else {
                this.showAudioInfo(audioId, this.pullPendingAudio(audioId), audioCache);
            }
        });

        this.setRequestTimer();
    }

    showAudioInfo(audioId, audioRows, audioData) {
        audioRows = Array.isArray(audioRows) ? audioRows : [audioRows];

        if (audioData.primary.size !== null && audioData.primary.duration !== null && audioData.primary.quality === null) {
            this.updateAudioData(audioData, 'quality', this.calcQuality(audioData.primary.size, audioData.primary.duration));
        }

        if (!audioData.secondary.filename && this.app.settings.audio_downlink) {
            let performerNode = audioRows[0].querySelector('.audio_performer'),
                titleNode = audioRows[0].querySelector('.audio_title_inner');                

            audioData.secondary.filename = this.buildFilename(
                performerNode ? performerNode.innerText : '', 
                titleNode ? titleNode.innerText : ''
            );
        }

        if (audioData.secondary.saveToCache) {
            this.app.coreMessage('saveAudioCache', {
                audioId: audioId,
                audioData: audioData.primary
            });
        }

        // ------------------------

        audioRows.forEach((audioRow) => {
            if (this.app.settings.audio_info) {
                let labelsModel = {
                    tag: 'div',
                    class: [ 'audio_extended_info'] ,
                    child: []
                }

                if (this.app.settings.audio_info == 1 && audioData.primary.size && audioData.primary.quality) {
                    labelsModel.class.push('quality_and_size');
                }

                if ((this.app.settings.audio_info == 1 || this.app.settings.audio_info == 2) && audioData.primary.quality) {
                    labelsModel.child.push({ tag: 'span', innerHTML: audioData.primary.quality });
                }

                if ((this.app.settings.audio_info == 1 || this.app.settings.audio_info == 3) && audioData.primary.size) {
                    labelsModel.child.push({ tag: 'span', innerHTML: this.app.formatSize(audioData.primary.size) });
                }

                if (audioData.secondary.datasetAudio) {
                    audioRow.dataset.audio = audioData.secondary.datasetAudio;
                }

                this.app.prependNode(audioRow.querySelector('.audio_duration_wrap'), labelsModel);

                requestAnimationFrame(() => audioRow.classList.add('has_extended_info'));
            }

            if (this.app.settings.audio_downlink) {
                audioRow.classList.add('has_download_link');

                let tooltipOptions = {
                    text: this.app.lang('tt_dl_audio'),
                    black: 1,
                    shift: [7, 5, 0],
                    needLeft: true
                };

                if (audioRow.closest('._im_mess_stack')) {
                    tooltipOptions.appendParentCls = '_im_mess_stack';
                    tooltipOptions.shift = [7, 10, 0];
                    tooltipOptions.noZIndex = true;
                }

                if (audioRow.closest('.top_notify_wrap')) {
                    tooltipOptions.appendParentCls = 'top_notify_wrap';
                }

                tooltipOptions = JSON.stringify(tooltipOptions);

                this.app.prependNode(
                    audioRow.querySelector('.audio_acts'),
                    {
                        tag: 'div',
                        class: 'audio_download_link',
                        data: { nodrag: 1 },
                        child: {
                            tag: 'div',
                            draggable: 'true',
                            events: [ [ 'dragstart', this.app.downloadFile, this.app ] ],
                            child: {
                                tag: 'a',
                                draggable: 'false',
                                href: audioData.primary.url,
                                download: audioData.secondary.filename,
                                data: { type: 'audio/mpeg' },
                                onmouseover: `showTooltip(this, ${tooltipOptions})`,
                                events: [ [ 'click', this.app.downloadFile, this.app ] ]
                            }
                        }
                    }                    
                );
            }
        });
    }
}

let vkFlex = window.vkFlex = new Injection();

})();