#!/bin/sh

CFGPATH="/home/lljk/.config/conky"

killall conky
for item in `ls ${CFGPATH}`; do
    conky -c ${CFGPATH}/${item} &
done
