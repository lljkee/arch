vamox icon theme
Created by Darío Badagnani and Emiliano Luciani
Creative Commons by-sa 3.0 - vamox.blogspot.com


Changelog:

2.1.1

New emblems, more colorfull and detailed for all themes

2.1
Vamox Argentum (grey) added
app / Gambas ( suggested by Patricio Prieto Garay )

2.0.3
Battery icons correction (?)
Printer Simbolic and printer network symbolic
"Jacarandá" color
Clear file ( / )
Delete file ( X ) on shredded paper


2.0.2
next track border fixed
New icon for Dev in categories
new start-here icons
system logout different of app exit


2.0.1
Camera device fixes


2.0
symbolic icons - devices
scanner and dial icon

1.9.3

app: amazon desura, gmail fonts evince fonts mate-system-log mate-energy osmo freemind simple-scan
devices: (symbolic) dialpad scanner computer camera webcam Simlink
actions: add reduce symbolic reduced to 16x16
actions: view-list and view-grid redraw
mate-ceibo: corrected some colors for better contrast
change copy and paste color to color of theme
search icons changed to hollow center gnome-dev-symlink
status: battery symbolic and network 
MEDIA symbolic reduced to 16x 16 for TOTEM


V 1.9.2

gnome-software added (for fedora)
mimetypes gpg fixed
new symbolic icons (fedora and ubuntu compatibility)


1.2
desktop locale and launcher
symbolic icons added
gcompris gnome-documents gnome-clocks Rythmbox brasero cheese gvim.svg
engrampa new version
chromium-browser.svg
thunderbird-icon.svg
accessories-dictionary.svg
calibre-gui.svg
caja-dropbox.svg
hexchat.svg 
mate-notification-daemon
wine, wine unistaller, winecfg

thanks to infirit of MATE forums


MATE 1.1
dropbox and bluetooth
volume without border
roller as duplicate of engrapa
libreoffice icons
stock-weather added
delete ref heavy files
evince desura and many other icons(apps)

MATE 1.0

some control panel
gpm-inhibition
Brightness icon
Green version (mate)
volumne icon changed
svg icon changed (mimetypes)
weather moon and fog fixed
repeat media icon
Mouse & date-time (control panel)
...

1.8
GTK media foward
media eject (caja)
NM connecting animations
pidgin status icons
status/missing image
bigger text fixed
Banshee icon and shuffle button


1.7
home folder
images folder
new start-here (Huayra logo)
corrected ascending
dozens of mimetypes redone



